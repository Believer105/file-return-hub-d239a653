import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { type, courseContent, message, history, question, userAnswer, correctAnswer } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY not configured");

    let systemPrompt = "";
    let userPrompt = "";

    if (type === "chat") {
      systemPrompt = `You are a helpful study assistant. Answer questions ONLY based on the following course material. If the answer is not in the material, say so politely. Be concise and educational.

COURSE MATERIAL:
${courseContent?.substring(0, 15000) || "No content available."}`;
      userPrompt = message;
    } else if (type === "quiz") {
      systemPrompt = `Generate exactly 5 quiz questions from this material. Return ONLY valid JSON with this structure:
{"questions":[{"type":"mcq","question":"...","options":["A","B","C","D"],"correctAnswer":"..."},{"type":"short","question":"...","correctAnswer":"..."}]}
Mix 3 MCQs and 2 short answer questions. Base questions ONLY on the material provided.`;
      userPrompt = `MATERIAL:\n${courseContent?.substring(0, 10000) || "No content."}`;
    } else if (type === "grade") {
      systemPrompt = `Grade this answer from 0-10 and provide brief feedback. Return ONLY JSON: {"score":N,"feedback":"..."}`;
      userPrompt = `Question: ${question}\nCorrect answer: ${correctAnswer}\nStudent answer: ${userAnswer}`;
    } else if (type === "flashcards") {
      systemPrompt = `Create 8-12 flashcards from this material. Return ONLY JSON: {"flashcards":[{"front":"term/question","back":"definition/answer"}]}`;
      userPrompt = `MATERIAL:\n${courseContent?.substring(0, 10000) || "No content."}`;
    } else if (type === "summary") {
      systemPrompt = `Create a structured summary. Return ONLY JSON: {"summary":{"concepts":["..."],"definitions":["..."],"takeaways":["..."]}}. Each array should have 4-6 items.`;
      userPrompt = `MATERIAL:\n${courseContent?.substring(0, 12000) || "No content."}`;
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${LOVABLE_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          ...(history || []),
          { role: "user", content: userPrompt },
        ],
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("AI Gateway error:", response.status, errorText);
      if (response.status === 429) return new Response(JSON.stringify({ error: "Rate limit exceeded" }), { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      if (response.status === 402) return new Response(JSON.stringify({ error: "Payment required" }), { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      throw new Error("AI gateway error");
    }

    const data = await response.json();
    let content = data.choices?.[0]?.message?.content || "";

    if (type === "chat") {
      return new Response(JSON.stringify({ response: content }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Parse JSON response for other types
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) content = jsonMatch[0];
      const parsed = JSON.parse(content);
      return new Response(JSON.stringify(parsed), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    } catch {
      console.error("Failed to parse AI response:", content);
      throw new Error("Invalid AI response format");
    }
  } catch (error) {
    console.error("Error:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: errorMessage }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
