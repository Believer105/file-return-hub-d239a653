import { useState, useEffect, useRef } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, MessageCircle, Brain, Layers, FileText, Send, Loader2, Zap, RotateCcw, ChevronLeft, ChevronRight, CheckCircle, XCircle } from "lucide-react";

interface Course {
  id: string;
  name: string;
  content: string | null;
}

interface Message {
  role: "user" | "assistant";
  content: string;
}

interface Flashcard {
  front: string;
  back: string;
}

interface QuizQuestion {
  type: "mcq" | "short";
  question: string;
  options?: string[];
  correctAnswer: string;
}

export default function CourseView() {
  const { id } = useParams<{ id: string }>();
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [course, setCourse] = useState<Course | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("study");
  
  // Study tab state
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [chatLoading, setChatLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Quiz state
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string>("");
  const [shortAnswer, setShortAnswer] = useState("");
  const [quizResults, setQuizResults] = useState<{correct: boolean; feedback: string}[]>([]);
  const [quizLoading, setQuizLoading] = useState(false);
  const [quizComplete, setQuizComplete] = useState(false);
  
  // Flashcards state
  const [flashcards, setFlashcards] = useState<Flashcard[]>([]);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [flashcardsLoading, setFlashcardsLoading] = useState(false);
  
  // Summary state
  const [summary, setSummary] = useState<{concepts: string[]; definitions: string[]; takeaways: string[]} | null>(null);
  const [summaryLoading, setSummaryLoading] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) navigate("/auth");
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (user && id) fetchCourse();
  }, [user, id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const fetchCourse = async () => {
    try {
      const { data, error } = await supabase.from("courses").select("*").eq("id", id).single();
      if (error) throw error;
      setCourse(data);
    } catch (error) {
      toast({ title: "Error", description: "Course not found.", variant: "destructive" });
      navigate("/dashboard");
    } finally {
      setLoading(false);
    }
  };

  const callAI = async (type: string, data: any) => {
    const response = await supabase.functions.invoke("ai-assistant", {
      body: { type, courseContent: course?.content, ...data },
    });
    if (response.error) throw response.error;
    return response.data;
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || chatLoading) return;
    const userMessage = inputMessage.trim();
    setInputMessage("");
    setMessages(prev => [...prev, { role: "user", content: userMessage }]);
    setChatLoading(true);
    
    try {
      const result = await callAI("chat", { message: userMessage, history: messages });
      setMessages(prev => [...prev, { role: "assistant", content: result.response }]);
    } catch (error) {
      toast({ title: "Error", description: "Failed to get response.", variant: "destructive" });
    } finally {
      setChatLoading(false);
    }
  };

  const generateQuiz = async () => {
    setQuizLoading(true);
    setQuizQuestions([]);
    setQuizResults([]);
    setCurrentQuestionIndex(0);
    setQuizComplete(false);
    
    try {
      const result = await callAI("quiz", {});
      setQuizQuestions(result.questions);
    } catch (error) {
      toast({ title: "Error", description: "Failed to generate quiz.", variant: "destructive" });
    } finally {
      setQuizLoading(false);
    }
  };

  const submitQuizAnswer = async () => {
    const question = quizQuestions[currentQuestionIndex];
    const answer = question.type === "mcq" ? selectedAnswer : shortAnswer;
    
    if (!answer.trim()) {
      toast({ title: "Answer required", variant: "destructive" });
      return;
    }

    let isCorrect = false;
    let feedback = "";

    if (question.type === "mcq") {
      isCorrect = answer === question.correctAnswer;
      feedback = isCorrect ? "Correct!" : `Incorrect. The correct answer is: ${question.correctAnswer}`;
    } else {
      try {
        const result = await callAI("grade", { question: question.question, userAnswer: answer, correctAnswer: question.correctAnswer });
        isCorrect = result.score >= 7;
        feedback = result.feedback;
      } catch {
        feedback = "Could not grade answer.";
      }
    }

    setQuizResults(prev => [...prev, { correct: isCorrect, feedback }]);
    setSelectedAnswer("");
    setShortAnswer("");

    if (currentQuestionIndex < quizQuestions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      setQuizComplete(true);
    }
  };

  const generateFlashcards = async () => {
    setFlashcardsLoading(true);
    try {
      const result = await callAI("flashcards", {});
      setFlashcards(result.flashcards);
      setCurrentCardIndex(0);
      setIsFlipped(false);
    } catch (error) {
      toast({ title: "Error", description: "Failed to generate flashcards.", variant: "destructive" });
    } finally {
      setFlashcardsLoading(false);
    }
  };

  const generateSummary = async () => {
    setSummaryLoading(true);
    try {
      const result = await callAI("summary", {});
      setSummary(result.summary);
    } catch (error) {
      toast({ title: "Error", description: "Failed to generate summary.", variant: "destructive" });
    } finally {
      setSummaryLoading(false);
    }
  };

  if (loading || authLoading) {
    return <div className="min-h-screen flex items-center justify-center bg-background"><Loader2 className="w-8 h-8 text-primary animate-spin" /></div>;
  }

  const quizScore = quizResults.filter(r => r.correct).length;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="border-b border-border bg-card/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate("/dashboard")}><ArrowLeft className="w-5 h-5" /></Button>
          <Link to="/dashboard" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center"><Zap className="w-4 h-4 text-primary-foreground" /></div>
          </Link>
          <h1 className="text-lg font-semibold text-foreground truncate">{course?.name}</h1>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="study" className="gap-2"><MessageCircle className="w-4 h-4" /><span className="hidden sm:inline">Study</span></TabsTrigger>
            <TabsTrigger value="quiz" className="gap-2"><Brain className="w-4 h-4" /><span className="hidden sm:inline">Quiz</span></TabsTrigger>
            <TabsTrigger value="flashcards" className="gap-2"><Layers className="w-4 h-4" /><span className="hidden sm:inline">Flashcards</span></TabsTrigger>
            <TabsTrigger value="summary" className="gap-2"><FileText className="w-4 h-4" /><span className="hidden sm:inline">Summary</span></TabsTrigger>
          </TabsList>

          <TabsContent value="study" className="h-[calc(100vh-220px)] flex flex-col">
            <Card variant="glass" className="flex-1 flex flex-col overflow-hidden">
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.length === 0 && (
                  <div className="text-center text-muted-foreground py-12">
                    <MessageCircle className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Ask questions about your course material</p>
                  </div>
                )}
                {messages.map((msg, i) => (
                  <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                    <div className={`max-w-[80%] rounded-xl px-4 py-3 ${msg.role === "user" ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"}`}>
                      <p className="whitespace-pre-wrap">{msg.content}</p>
                    </div>
                  </motion.div>
                ))}
                {chatLoading && <div className="flex justify-start"><div className="bg-secondary rounded-xl px-4 py-3"><Loader2 className="w-5 h-5 animate-spin" /></div></div>}
                <div ref={messagesEndRef} />
              </div>
              <div className="p-4 border-t border-border">
                <form onSubmit={(e) => { e.preventDefault(); handleSendMessage(); }} className="flex gap-2">
                  <Input placeholder="Ask about your material..." value={inputMessage} onChange={(e) => setInputMessage(e.target.value)} />
                  <Button type="submit" disabled={chatLoading}><Send className="w-4 h-4" /></Button>
                </form>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="quiz">
            {quizQuestions.length === 0 ? (
              <Card variant="glass" className="p-12 text-center">
                <Brain className="w-16 h-16 mx-auto mb-4 text-primary opacity-50" />
                <h3 className="text-xl font-semibold mb-2">Generate a Quiz</h3>
                <p className="text-muted-foreground mb-6">Test your knowledge with AI-generated questions</p>
                <Button variant="glow" onClick={generateQuiz} disabled={quizLoading}>{quizLoading ? <><Loader2 className="w-5 h-5 animate-spin mr-2" />Generating...</> : "Generate Quiz"}</Button>
              </Card>
            ) : quizComplete ? (
              <Card variant="glass" className="p-8 text-center">
                <h3 className="text-2xl font-bold mb-4">Quiz Complete!</h3>
                <p className="text-4xl font-bold text-primary mb-4">{quizScore}/{quizQuestions.length}</p>
                <p className="text-muted-foreground mb-6">You got {Math.round((quizScore/quizQuestions.length)*100)}% correct</p>
                <Button variant="glow" onClick={generateQuiz}><RotateCcw className="w-4 h-4 mr-2" />Try Again</Button>
              </Card>
            ) : (
              <Card variant="glass" className="p-6">
                <div className="mb-4 flex justify-between text-sm text-muted-foreground">
                  <span>Question {currentQuestionIndex + 1} of {quizQuestions.length}</span>
                  <span>{quizQuestions[currentQuestionIndex].type === "mcq" ? "Multiple Choice" : "Short Answer"}</span>
                </div>
                <h3 className="text-lg font-medium mb-6">{quizQuestions[currentQuestionIndex].question}</h3>
                {quizQuestions[currentQuestionIndex].type === "mcq" ? (
                  <div className="space-y-3 mb-6">
                    {quizQuestions[currentQuestionIndex].options?.map((opt, i) => (
                      <button key={i} onClick={() => setSelectedAnswer(opt)} className={`w-full text-left p-4 rounded-lg border transition-all ${selectedAnswer === opt ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"}`}>{opt}</button>
                    ))}
                  </div>
                ) : (
                  <Input placeholder="Your answer..." value={shortAnswer} onChange={(e) => setShortAnswer(e.target.value)} className="mb-6" />
                )}
                <Button variant="glow" onClick={submitQuizAnswer} className="w-full">Submit Answer</Button>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="flashcards">
            {flashcards.length === 0 ? (
              <Card variant="glass" className="p-12 text-center">
                <Layers className="w-16 h-16 mx-auto mb-4 text-primary opacity-50" />
                <h3 className="text-xl font-semibold mb-2">Generate Flashcards</h3>
                <p className="text-muted-foreground mb-6">Create flashcards from your study material</p>
                <Button variant="glow" onClick={generateFlashcards} disabled={flashcardsLoading}>{flashcardsLoading ? <><Loader2 className="w-5 h-5 animate-spin mr-2" />Generating...</> : "Generate Flashcards"}</Button>
              </Card>
            ) : (
              <div className="max-w-xl mx-auto">
                <div className="perspective-1000 mb-6" style={{ perspective: "1000px" }}>
                  <motion.div onClick={() => setIsFlipped(!isFlipped)} className="relative w-full h-64 cursor-pointer" style={{ transformStyle: "preserve-3d" }} animate={{ rotateY: isFlipped ? 180 : 0 }} transition={{ duration: 0.6 }}>
                    <Card variant="glow" className="absolute inset-0 flex items-center justify-center p-6 backface-hidden" style={{ backfaceVisibility: "hidden" }}>
                      <p className="text-xl text-center">{flashcards[currentCardIndex].front}</p>
                    </Card>
                    <Card variant="glass" className="absolute inset-0 flex items-center justify-center p-6" style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)" }}>
                      <p className="text-lg text-center text-muted-foreground">{flashcards[currentCardIndex].back}</p>
                    </Card>
                  </motion.div>
                </div>
                <div className="flex items-center justify-between">
                  <Button variant="outline" onClick={() => { setCurrentCardIndex(prev => Math.max(0, prev - 1)); setIsFlipped(false); }} disabled={currentCardIndex === 0}><ChevronLeft className="w-4 h-4" /></Button>
                  <span className="text-muted-foreground">{currentCardIndex + 1} / {flashcards.length}</span>
                  <Button variant="outline" onClick={() => { setCurrentCardIndex(prev => Math.min(flashcards.length - 1, prev + 1)); setIsFlipped(false); }} disabled={currentCardIndex === flashcards.length - 1}><ChevronRight className="w-4 h-4" /></Button>
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="summary">
            {!summary ? (
              <Card variant="glass" className="p-12 text-center">
                <FileText className="w-16 h-16 mx-auto mb-4 text-primary opacity-50" />
                <h3 className="text-xl font-semibold mb-2">Generate Summary</h3>
                <p className="text-muted-foreground mb-6">Get a structured overview of your material</p>
                <Button variant="glow" onClick={generateSummary} disabled={summaryLoading}>{summaryLoading ? <><Loader2 className="w-5 h-5 animate-spin mr-2" />Generating...</> : "Generate Summary"}</Button>
              </Card>
            ) : (
              <div className="grid gap-6 md:grid-cols-3">
                <Card variant="glass" className="p-6">
                  <h3 className="font-semibold text-primary mb-4">Core Concepts</h3>
                  <ul className="space-y-2">{summary.concepts.map((c, i) => <li key={i} className="text-sm text-muted-foreground">• {c}</li>)}</ul>
                </Card>
                <Card variant="glass" className="p-6">
                  <h3 className="font-semibold text-primary mb-4">Key Definitions</h3>
                  <ul className="space-y-2">{summary.definitions.map((d, i) => <li key={i} className="text-sm text-muted-foreground">• {d}</li>)}</ul>
                </Card>
                <Card variant="glass" className="p-6">
                  <h3 className="font-semibold text-primary mb-4">Key Takeaways</h3>
                  <ul className="space-y-2">{summary.takeaways.map((t, i) => <li key={i} className="text-sm text-muted-foreground">• {t}</li>)}</ul>
                </Card>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
